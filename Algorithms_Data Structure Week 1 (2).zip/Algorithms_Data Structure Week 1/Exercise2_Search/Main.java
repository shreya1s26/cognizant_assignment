public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Phone", "Electronics"),
            new Product(2, "Shirt", "Apparel"),
            new Product(3, "Laptop", "Electronics")
        };

        // Test linear search
        Product result1 = LinearSearch.search(products, "Shirt");
        System.out.println("Linear Search: " + (result1 != null ? result1 : "Not found"));

        // Test binary search
        Product result2 = BinarySearch.search(products, "Laptop");
        System.out.println("Binary Search: " + (result2 != null ? result2 : "Not found"));
    }
}
